library(shiny)
library(tidyverse)

ui <- fluidPage(
  
  numericInput("obs", "Number of observations", 6, min = 1, max = 20, width = "300px"),
  tableOutput("view")
)


server <- function(input, output) {
  
  dataset <- mpg
  
  output$view <- renderTable({
    head(dataset, n = (input$obs))
  })
  
  
}


shinyApp(ui, server)