library(shiny)
library(shinyjs)

ui <- fluidPage(
  useShinyjs(),
  radioButtons('city',
               'Choose a City',
              choices = c('Austin',
                          'Dallas',
                          'El Paso',
                          'Houston',
                          'San Antonio'),
              selected = 'San Antonio'
              
  ),
  
   textOutput("text")
  
)


server <- function(input, output) {
  
  
  delay(500, output$text <- renderText({
        
        paste("You selected", input$city)
    
   }))
  
  
}


shinyApp(ui = ui, server = server)

