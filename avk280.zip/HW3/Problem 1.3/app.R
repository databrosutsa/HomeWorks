library(shiny)
library(lubridate)

ui <- fluidPage(
  
  dateInput('date',
            'Date',
            value = "2017-09-19"
  ),
  
  textOutput("text")
  
)


server <- function(input, output) {
  
  
  
  output$text <- renderText({
    
     day(input$date)
    
  })
  
  
}


shinyApp(ui, server)