library(shiny)
library(ggplot2)


ui <- fluidPage(
  fluidRow(
    column(4,
           #Number of Observations Slider
           sliderInput("obs", "Number of Observations", value = 100, min = 50, max = 200),
           
           #Number of Bins Slider
           sliderInput("bins", "Number of Bins", value = 20, min = 10, max = 50),
           
           #Color Fill Drop Down
           selectInput("color", "Color Fill",
                       choices = c("blue","red","green","yellow", "black"),
                       selected = "blue"
           ),
           
           #Border Color Drop Down
           selectInput("border", "Border Color",
                       choices = c("red","white","black"),
                       selected = "red"
                       
           )
    ),
    column(8,
           plotOutput("histogram")
    )
  )
)


server <- function(input, output) {
  
  
  output$histogram <- renderPlot({
    
    n = input$obs # some number
    
    randvec = rnorm(n)
    generated <- data.frame(randvec)
    random <- "Random Numbers"
    
    ggplot(data = generated, aes(x = randvec)) +
      geom_histogram( bins = input$bins, fill = input$color, color = input$border) + 
      labs(x = "Random Numbers", y = "Count")
    
})
  
  
}


shinyApp(ui, server)